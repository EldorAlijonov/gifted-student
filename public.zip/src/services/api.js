import axios from "axios";
import { getItem } from "../helpers/storage";
axios.defaults.baseURL = "https://iqtidorlitalaba.pythonanywhere.com/api/";

axios.interceptors.request.use(config => {
    const token = getItem("token")
    const authorization = token ? `Token ${token}` : '';
    config.headers.Authorization = authorization;
    return config;
})

export default axios;